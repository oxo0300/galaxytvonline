--------------------
Plugin: PHP Tidy for MODx
--------------------
Version: 1.0.0
Since: December 15, 2011
Author: goldsky <goldsky@fastmail.fm>
License: GNU GPLv2 (or later at your option)

This is an implementation of PHP Tidy in MODx.
Please see the documentation at:
http://php.net/manual/en/book.tidy.php
http://tidy.sourceforge.net/docs/quickref.html

Thanks for using PHP Tidy for MODx!
goldsky
goldsky@fastmail.fm