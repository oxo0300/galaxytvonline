--------------------
Snippet: oembed
--------------------
Version: 0.2.1-beta
Since: February 08, 2010
Author: Oleh Burkhay <atma@atmaworks.com>

An oEmbed implementation for MODx Revolution. oEmbed format official site http://oembed.com/

Demos and documentation:
http://www.atmaworks.com/blog/oembed-modx-component.html

Example call:
[[oembed? &url=`http://www.youtube.com/watch?v=nErbxJloM8s`]]

--------------------
Plugin: oembed
--------------------
Version: 0.2.1-beta
Since: February 13, 2010
Author: Oleh Burkhay <atma@atmaworks.com>

Ability to autoembed media via URLs in content for known providers
