--------------------
Extra: Cron Manager
--------------------
Version: 1.0.1
 
With the Cron manager you're able to create cronjobs within the manager. When the right script is added to your cronjobs list you could manage snippets as cronjob scripts. It can run every minute and you could pass properties or propertysets to your snippet in the cronjob.

See documentation for more details;
http://rtfm.modx.com/display/ADDON/CronManager