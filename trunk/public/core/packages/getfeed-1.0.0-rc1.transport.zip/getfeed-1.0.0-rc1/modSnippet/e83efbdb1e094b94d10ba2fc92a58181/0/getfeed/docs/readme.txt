----------------------------
Extension: getFeed
----------------------------
Version: 1.0.0
Since: June 11th, 2010
Author: Jason Coward <jason@modxcms.com> and Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

A simple snippet to retrieve an RSS feed and iterate the feed items using a Chunk.
