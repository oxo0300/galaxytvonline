--------------------
Extension: dbapi
--------------------
Version: 1.0.0-pl
Released: March 8, 2011
Since: March 7, 2011
Author: Jason Coward <jason@modx.com>

A MODX Revolution Extra for 2.1+, the dbapi service class provides access to legacy MODX DBAPI methods.
