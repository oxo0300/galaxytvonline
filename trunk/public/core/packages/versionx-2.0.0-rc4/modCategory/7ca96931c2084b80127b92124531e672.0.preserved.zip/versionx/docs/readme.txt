--------------------
VersionX
--------------------
Version: 2.0.0
Author: Mark Hamstra <hello@markhamstra.com>
--------------------

VersionX is a utility tool for MODX Revolution that will help you keep track of your content in Resources, Templates, Chunks, Snippets and Plugins. Every save is recorded and can easily be looked back and compared through the component.

NOTE: VersionX 2.0 is a complete rewrite and is NOT compatible with VersionX 1.0. You will be able to snapshot all your existing content into the new 2.0 tables, however you cannot re-use any data stored in there. NOTE2: While the UI is not finished (I welcome contributors!), all elements and resources are indeed being stored to the database.

Have fun!
If you would like to donate towards development, please visit http://www.markhamstra.com/open-source/versionx/ - thanks!
