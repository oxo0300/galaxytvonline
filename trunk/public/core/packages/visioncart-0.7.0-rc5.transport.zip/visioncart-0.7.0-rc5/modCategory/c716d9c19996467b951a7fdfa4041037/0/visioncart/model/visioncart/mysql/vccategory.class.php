<?php
require_once (dirname(dirname(__FILE__)) . '/vccategory.class.php');
class vcCategory_mysql extends vcCategory {}