<?php

$moduleProperties = array();