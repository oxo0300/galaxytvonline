<?php
class vcCategory extends xPDOSimpleObject {}