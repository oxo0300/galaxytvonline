<?php
require_once (dirname(dirname(__FILE__)) . '/vcorder.class.php');
class vcOrder_mysql extends vcOrder {}