<?php
class vcShop extends xPDOSimpleObject {}