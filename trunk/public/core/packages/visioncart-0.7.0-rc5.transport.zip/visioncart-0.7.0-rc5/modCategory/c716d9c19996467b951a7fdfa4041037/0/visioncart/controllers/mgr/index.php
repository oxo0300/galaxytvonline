<?php

return '<div id="vc-ajax-haze" class="vc-ajax-haze"></div><div id="visioncart-container"></div><div id="vc-ajax-haze" class="vc-ajax-haze"></div>';