<?php

return '<div id="vc-ajax-haze" class="vc-ajax-haze"></div><iframe width="0" style="visibility: hidden;" height="0" frameborder="0" name="file-upload" id="file-upload" src=""></iframe><div id="visioncart-container"></div>'; 