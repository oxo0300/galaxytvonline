<?php
class vcProductOption extends xPDOSimpleObject {}