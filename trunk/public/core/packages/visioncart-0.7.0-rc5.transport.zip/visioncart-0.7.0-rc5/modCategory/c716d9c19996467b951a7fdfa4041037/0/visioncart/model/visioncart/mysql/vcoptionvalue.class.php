<?php
require_once (dirname(dirname(__FILE__)) . '/vcoptionvalue.class.php');
class vcOptionValue_mysql extends vcOptionValue {}