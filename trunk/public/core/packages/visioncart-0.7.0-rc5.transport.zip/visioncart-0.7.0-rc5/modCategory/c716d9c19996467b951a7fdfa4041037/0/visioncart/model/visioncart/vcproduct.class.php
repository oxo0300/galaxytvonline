<?php
class vcProduct extends xPDOSimpleObject {}