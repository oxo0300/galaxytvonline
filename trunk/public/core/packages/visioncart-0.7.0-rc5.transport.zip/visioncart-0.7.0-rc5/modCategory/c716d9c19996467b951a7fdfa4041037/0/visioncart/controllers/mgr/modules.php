<?php

return '<div id="visioncart-container"></div><div id="vc-ajax-haze" class="vc-ajax-haze"></div>';