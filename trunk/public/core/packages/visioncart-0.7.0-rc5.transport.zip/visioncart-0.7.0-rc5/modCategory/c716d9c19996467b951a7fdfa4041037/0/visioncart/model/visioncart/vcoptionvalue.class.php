<?php
class vcOptionValue extends xPDOSimpleObject {}