<?php
/**
 * @package visioncart
 */

$vc =& $modx->visioncart;

return $vc->wayFinder($scriptProperties);