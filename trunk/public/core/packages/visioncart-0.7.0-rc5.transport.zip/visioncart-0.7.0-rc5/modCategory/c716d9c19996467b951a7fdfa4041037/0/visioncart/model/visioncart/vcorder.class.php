<?php
class vcOrder extends xPDOSimpleObject {}