<?php
class vcProductCategory extends xPDOSimpleObject {}