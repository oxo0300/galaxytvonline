<?php

$moduleProperties = array();