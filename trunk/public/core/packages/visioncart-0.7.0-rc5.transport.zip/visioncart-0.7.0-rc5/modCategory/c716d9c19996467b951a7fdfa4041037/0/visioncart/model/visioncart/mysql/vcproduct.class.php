<?php
require_once (dirname(dirname(__FILE__)) . '/vcproduct.class.php');
class vcProduct_mysql extends vcProduct {}