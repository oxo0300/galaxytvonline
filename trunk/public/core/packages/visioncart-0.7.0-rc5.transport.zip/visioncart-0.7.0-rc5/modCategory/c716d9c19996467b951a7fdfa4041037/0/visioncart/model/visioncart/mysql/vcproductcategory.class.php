<?php
require_once (dirname(dirname(__FILE__)) . '/vcproductcategory.class.php');
class vcProductCategory_mysql extends vcProductCategory {}