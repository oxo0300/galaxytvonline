<?php
require_once (dirname(dirname(__FILE__)) . '/vcoption.class.php');
class vcOption_mysql extends vcOption {}