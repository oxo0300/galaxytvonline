<?php
require_once (dirname(dirname(__FILE__)) . '/vcshop.class.php');
class vcShop_mysql extends vcShop {}