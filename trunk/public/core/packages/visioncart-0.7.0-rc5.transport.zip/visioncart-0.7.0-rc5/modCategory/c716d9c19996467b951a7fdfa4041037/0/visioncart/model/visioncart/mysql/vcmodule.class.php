<?php
require_once (dirname(dirname(__FILE__)) . '/vcmodule.class.php');
class vcModule_mysql extends vcModule {}