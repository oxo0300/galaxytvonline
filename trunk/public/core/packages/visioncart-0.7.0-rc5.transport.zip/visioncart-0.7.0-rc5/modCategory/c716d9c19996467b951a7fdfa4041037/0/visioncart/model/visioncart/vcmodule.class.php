<?php
class vcModule extends xPDOSimpleObject {}