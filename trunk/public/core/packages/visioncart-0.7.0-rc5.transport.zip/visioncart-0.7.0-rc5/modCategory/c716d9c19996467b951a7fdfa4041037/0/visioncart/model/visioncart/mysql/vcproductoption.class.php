<?php
require_once (dirname(dirname(__FILE__)) . '/vcproductoption.class.php');
class vcProductOption_mysql extends vcProductOption {}