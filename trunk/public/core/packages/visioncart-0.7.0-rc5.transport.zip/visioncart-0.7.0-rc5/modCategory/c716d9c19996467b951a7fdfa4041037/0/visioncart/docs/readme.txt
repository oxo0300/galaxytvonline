+-----------------+
| Read this first |
+-----------------+
After installation you can follow the templating tutorial: 
http://rtfm.modx.com/display/ADDON/VisionCart.Templating

VisionCart is developed and maintained by Sofito (http://www.sofito.nl)
located in the Netherlands.

VisionCart website: http://www.visioncart.net
VisionCart documentation: http://rtfm.modx.com/display/ADDON/VisionCart
VisionCart bug reports: http://bugs.modx.com/projects/visioncart
VisionCart forums: http://modxcms.com/forums/index.php/board,393.0.html

Follow the core developers on twitter:
http://www.twitter.com/b03tz
http://www.twitter.com/Dimmy01