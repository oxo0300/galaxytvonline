<?php
class vcOption extends xPDOSimpleObject {}