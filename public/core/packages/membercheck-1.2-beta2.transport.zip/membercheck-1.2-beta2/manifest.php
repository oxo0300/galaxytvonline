<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '8b7e6f4c9e151c13b838164c4be6dfa3',
      'native_key' => 1,
      'filename' => 'modSnippet/3afc28046137bef901b34bf7c33d458c.vehicle',
    ),
  ),
);