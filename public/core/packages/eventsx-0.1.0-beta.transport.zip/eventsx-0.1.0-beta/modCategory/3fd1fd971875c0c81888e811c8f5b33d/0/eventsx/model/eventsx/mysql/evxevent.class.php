<?php
require_once (dirname(dirname(__FILE__)) . '/evxevent.class.php');
class evxEvent_mysql extends evxEvent {}