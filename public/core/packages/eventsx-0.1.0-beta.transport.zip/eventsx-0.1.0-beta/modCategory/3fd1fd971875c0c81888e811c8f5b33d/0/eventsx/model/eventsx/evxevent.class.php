<?php
class evxEvent extends xPDOSimpleObject {}