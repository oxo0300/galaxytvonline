<?php
require_once (dirname(dirname(__FILE__)) . '/modcronjob.class.php');
class modCronjob_mysql extends modCronjob {}