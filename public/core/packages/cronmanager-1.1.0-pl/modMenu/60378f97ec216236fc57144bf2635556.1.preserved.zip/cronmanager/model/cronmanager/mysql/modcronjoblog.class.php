<?php
require_once (dirname(dirname(__FILE__)) . '/modcronjoblog.class.php');
class modCronjobLog_mysql extends modCronjobLog {}